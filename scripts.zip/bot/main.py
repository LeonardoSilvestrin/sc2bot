"""The bot. The static map is read once, in ``on_start``; then every frame, in order:

ATTENTION -> AWARENESS -> EGO (strategy: assessment -> intent; planners and their
missions) -> BODY (engine -> behaviors) -> LOGS

The Engine's result is kept for the next frame: it is the feedback the
missions read about what they were granted. Nothing is planned or allocated
twice in a frame.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from hashlib import sha256
from random import Random
from time import perf_counter

from ares import AresBot
from sc2.data import Result

from bot.attention import AttentionState, MapView, observe, read_map
from bot.awareness import AwarenessModel, AwarenessState
from bot.body import behaviors
from bot.body.behaviors.attack import MicroReport
from bot.body.behaviors.detection import DetectionReport
from bot.body.behaviors.economy import SpawnMode
from bot.body.behaviors.sensor_towers import SensorTowerReport
from bot.body.engine import Engine, EngineResult
from bot.ego.missions import MissionView
from bot.ego.planners import EconomyPlan, IntelPlan, Proposal, StructurePlan, economy
from bot.ego.planners.defense import DefensePlanner
from bot.ego.planners.economy import CompositionPolicy, InvestmentConfig
from bot.ego.planners.economy.knowledge import styles
from bot.ego.planners.economy.knowledge.styles import BIO, ArmyStyle
from bot.ego.planners.intel import IntelPlanner
from bot.ego.planners.map_control import MapControlPlan, MapControlPlanner
from bot.ego.planners.offense import OffensePlan, OffensePlanner
from bot.ego.planners.structure_control import StructureControlPlanner
from bot.ego.strategy import StrategicIntent, StrategyModel
from bot.logs import Logs

DEFAULT_LATTICE_SPACING = 4


@dataclass(slots=True)
class Layers:
    """What persists from one frame to the next, per layer."""

    map_view: MapView
    logs: Logs
    # Chosen once, in `on_start`.
    army: ArmyStyle = BIO
    composition: CompositionPolicy = field(init=False)
    investment: InvestmentConfig = field(default_factory=InvestmentConfig)
    awareness: AwarenessModel = field(default_factory=AwarenessModel)
    strategy: StrategyModel = field(default_factory=StrategyModel)
    defense: DefensePlanner = field(default_factory=DefensePlanner)
    map_control: MapControlPlanner = field(default_factory=MapControlPlanner)
    offense: OffensePlanner = field(default_factory=OffensePlanner)
    intel: IntelPlanner = field(default_factory=IntelPlanner)
    structure_control: StructureControlPlanner = field(default_factory=StructureControlPlanner)
    engine: Engine = field(default_factory=Engine)
    # The last allocation, read by the missions on the next frame.
    feedback: EngineResult | None = None

    def __post_init__(self) -> None:
        self.composition = CompositionPolicy(self.army)

    def configs(self) -> dict[str, object]:
        return {
            "awareness": self.awareness.config,
            "strategy": self.strategy.config,
            "assessment": self.strategy.assessment.config,
            "map_control": self.map_control.config,
            "offense": self.offense.config,
            "structure_control": self.structure_control.config,
            "detection": self.intel.detection.config,
            "army": self.army,
            "composition": self.composition.config,
            "investment": self.investment,
        }


@dataclass(frozen=True, slots=True)
class Frame:
    attention: AttentionState
    awareness: AwarenessState
    intent: StrategicIntent
    map_control: MapControlPlan
    offense: OffensePlan
    proposals: tuple[Proposal, ...]
    economy: EconomyPlan
    structures: StructurePlan
    result: EngineResult
    spawn: SpawnMode
    micro: MicroReport
    intel: IntelPlan
    detected: DetectionReport
    tower_building: SensorTowerReport
    # Every mission a planner governed this frame, as it left the frame.
    missions: tuple[MissionView, ...] = ()

    @property
    def detection(self):
        """Compatibility view of Intel's detection decision."""

        return self.intel.detection

    @property
    def sensor_towers(self):
        """Compatibility view of Intel's infrastructure decision."""

        return self.intel.sensor_towers


def play_frame(bot, iteration: int, layers: Layers) -> Frame:
    laps = _Laps()
    attention = observe(bot, iteration, layers.map_view)
    laps.mark("attention")
    awareness = layers.awareness.infer(attention)
    laps.mark("awareness")
    # Every planner reads the same intent and serves it in its own domain.
    intent = layers.strategy.decide(attention, awareness)
    laps.mark("strategy")
    proposals = layers.defense.plan(attention, awareness, intent, layers.feedback)
    map_control = layers.map_control.plan(attention, awareness, intent)
    proposals += map_control.proposals
    # The offense assembles and falls back where MapControl holds the army.
    offense = layers.offense.plan(attention, awareness, intent, map_control.anchor, layers.feedback)
    proposals += offense.proposals
    intel = layers.intel.plan(attention, awareness, intent, layers.feedback)
    proposals += intel.proposals
    missions = layers.defense.views() + layers.offense.views() + layers.intel.views()
    economy_plan = economy.plan(
        attention,
        intent,
        layers.army,
        composition_policy=layers.composition,
        investment_config=layers.investment,
        awareness=awareness,
    )
    structures = layers.structure_control.plan(attention)
    laps.mark("planners")
    result = layers.engine.allocate(attention, proposals)
    layers.feedback = result
    laps.mark("engine")
    body = behaviors.execute(
        bot,
        attention,
        result,
        economy_plan,
        structures,
        intel,
    )
    laps.mark("behaviors")
    layers.logs.record(
        bot,
        attention,
        awareness,
        intent,
        map_control,
        offense,
        proposals,
        economy_plan,
        structures,
        result,
        body.spawn,
        body.micro,
        laps.times,
        intel=intel,
        detected=body.detection,
        tower_building=body.sensor_towers,
        infrastructure=body.infrastructure,
        missions=missions,
    )
    return Frame(
        attention,
        awareness,
        intent,
        map_control,
        offense,
        proposals,
        economy_plan,
        structures,
        result,
        body.spawn,
        body.micro,
        intel,
        body.detection,
        body.sensor_towers,
        missions,
    )


class MyBot(AresBot):
    def __init__(
        self,
        game_step_override: int | None = None,
        *,
        logs: Logs | None = None,
        lattice_spacing: int = DEFAULT_LATTICE_SPACING,
        army: str | None = None,
        style_seed: int | None = None,
    ):
        """
        Parameters
        ----------
        game_step_override :
            If provided, set the game_step to this value regardless of how it was
            specified elsewhere
        logs :
            Where the bot explains itself; silent by default (ladder).
        lattice_spacing :
            Map cells between the points Awareness reasons over.
        army :
            The army style to play, by name; None draws one for the enemy's race.
        style_seed :
            Reproducible style draw. When omitted, a stable opponent-id seed is
            used (zero outside a ladder match).
        """
        super().__init__(game_step_override)
        self.bot_logs = logs or Logs()
        self.lattice_spacing = lattice_spacing
        self.army = army
        self.style_seed = style_seed
        self.layers: Layers | None = None

    async def on_start(self) -> None:
        await super().on_start()
        map_view = read_map(self, lattice_spacing=self.lattice_spacing)
        seed = self.style_seed
        if seed is None:
            opponent = str(getattr(self, "opponent_id", "") or "")
            seed = int.from_bytes(sha256(opponent.encode("utf-8")).digest()[:8], "big")
        army = styles.choose(self.enemy_race, Random(seed), forced=self.army)
        # Nothing of the opening has been played yet.
        self.build_order_runner.switch_opening(army.opening, remove_completed=False)
        self.layers = Layers(map_view=map_view, logs=self.bot_logs, army=army)
        self.bot_logs.game_started(self, map_view, self.layers.configs())
        corridor = self.layers.structure_control.corridor(map_view)
        cleared = behaviors.structure_control.keep_clear(self, corridor)
        self.bot_logs.kept_clear(float(self.time), map_view, corridor, cleared)
        await self.chat_send(styles.announcement(army))

    async def on_step(self, iteration: int) -> None:
        await super().on_step(iteration)
        if self.layers is not None:
            play_frame(self, iteration, self.layers)

    async def on_end(self, game_result: Result) -> None:
        await super().on_end(game_result)
        self.bot_logs.game_ended(float(self.time), game_result)


class _Laps:
    def __init__(self) -> None:
        self._last = perf_counter()
        self.times: dict[str, float] = {}

    def mark(self, name: str) -> None:
        now = perf_counter()
        self.times[name] = (now - self._last) * 1000.0
        self._last = now
